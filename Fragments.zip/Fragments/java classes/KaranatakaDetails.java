package com.example.madhuri.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class KaranatakaDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.madhuri.myapplication.R.layout.activity_karanataka_details);
    }
}
